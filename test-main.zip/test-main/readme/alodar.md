---
title: Alone in the Dark Prologue-Grace - čeština
sidebar: false
---
<script setup lang="ts">
const people = {
  lead: [
    { name: "Pertim", role: "Vedení projektu"}
  ],
  l10n: [
    { name: "Pertim", role: "Překlad"},
    { name: "Pertim", role: "Korektura"},
  ],
  support: [
    { name: "savlozubaveverka, Tom Bombadil", role: "Technika, fonty"},
  ]
};
</script>

<div style="border-radius: 16px; overflow: hidden; margin-bottom: 16px;">
  <img src="https://i.imgur.com/g4RsRYV.jpeg">
</div> 

# Alone in the Dark Prologue-Grace – Čeština

![](https://img.shields.io/badge/přeloženo-100%25-darkgreen?style=for-the-badge)<br>
![](https://img.shields.io/badge/herní%20klient-steam-grey?style=for-the-badge) 
![](https://img.shields.io/badge/verze%20hry-aktuální-grey?style=for-the-badge) 
![](https://img.shields.io/badge/verze%20překladu-1.0-grey?style=for-the-badge)

------------
V tomto samostatném prologu k Alone in the Dark se ocitnete v kůži Grace Saundersové - jedenáctileté dívky, která doručuje dopis, když se něco strašlivě zvrtne...<br /><br />

## Členové týmu

Na překladu se podílejí následující lidé:

<PTeamMembers :members="people.lead" />

<PTeamMembers :members="people.l10n" />

<PTeamMembers :members="people.support" />

<PTeamMembers :members="people.partners" />

### Instalace:
cesta: rozbalte a nakopírujte do složky nainstalované hry <br />
nahradí to Angličtinu

## Ke stažení
[Stáhnout](https://fastshare.live/28409100/alone-in-the-dark-prologue-grace-cz.rar)







