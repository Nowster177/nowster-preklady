---
title: 00. Prezentace CZ do VotV
date: 2024-03-14
---

<PBlogHeader>
RTHWLDN hrál hru s mou češtinou
</PBlogHeader>

::: warning POZOR
Sleduj [hlavní stránku](/) projektu.
:::

<div style="display: flex; justify-content: space-around;">
 <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/GuyENhn1jMM?si=GuXqWow6O1pvNn1L" title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    allowfullscreen>
  </iframe>
</div>
