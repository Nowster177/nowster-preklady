---
title: 01. Další prezentace CZ do VotV
date: 2024-03-16
---

<PBlogHeader>
RTHWLDN hrál hru s mou češtinou
</PBlogHeader>

<div style="display: flex; justify-content: space-around;">
<iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/QZnkwc-Tabk?si=XsjqlKzAmQ2UhYDh" title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    allowfullscreen>
  </iframe>
</div>
<hr>
Fixnul jsem překlad u několika řádků.
